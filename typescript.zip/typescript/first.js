var empName = "Nikitha Vedant Madabhushi";
alert(empName);
