import {IPerson, UserData} from '../Person/PersonContract.ts';
class Employee implements IPerson{
    personId:number;
    personName:string;
    personAge:number;
}
class UserInfo implements UserData{
    
}