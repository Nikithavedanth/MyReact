function DisplayData(id, name) {
    console.log("Id is:".concat(id, " and Name is:").concat(name));
    console.log("Datatype of Id is:".concat(typeof (id), " and Datatype of Name is:").concat(typeof (name)));
}
DisplayData(101, "Nikitha");
DisplayData("102", "Nikki");
