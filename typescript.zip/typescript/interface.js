var empObj = {
    age: 23,
    gender: "Female",
    name: "Nikitha",
    empCode: 1234
};
// empObj.name="Nikitha";
// empObj.age=23;
// empObj.gender="Female";
// empObj.empCode=1234;
console.log("EmpId:".concat(empObj.empCode, ",Employee Name:").concat(empObj.name, ", Age:").concat(empObj.age, ",Gender:").concat(empObj.gender));
