var empName:string="Nikitha Vedant Madabhushi"
alert(empName);