export interface IPerson{
    personId:number;
    personName:string;
    personAge:number;
}
export interface UserData{
    name:string;
    id:number;
    job:string;
    isActive:boolean;
}